<?php
	
	// Test coordinates
	// '37.8267,-122.4233'
if(isset($_POST['submit'])){

	$location = htmlentities($_POST['location']);
	$coordinates = $location;

	$api_url = 'https://api.darksky.net/forecast/195f87245423cb9d8d249f7e444d77b6/'.$coordinates;

	$forecast = json_decode(file_get_contents($api_url));
	//echo '<pre>';
	//print_r($forecast);
	//echo '</pre>';

	
	// Current Conditions
	$temperature_current = round($forecast->currently->temperature);
	$summary_current = $forecast->currently->summary;
	$windspeed_current = round($forecast->currently->windSpeed);
	$humidity_current = $forecast->currently->humidity*100;

	// Set time zone based on location
	date_default_timezone_set('UTC');
}